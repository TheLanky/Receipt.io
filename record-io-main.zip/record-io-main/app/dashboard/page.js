import Dashboard from '../pages/dashboard';

export default function EditPage() {
  return <Dashboard />;
}
