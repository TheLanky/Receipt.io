import RemoveItem from '../pages/remove-item';

export default function LoginPage() {
  return <RemoveItem />;
}
