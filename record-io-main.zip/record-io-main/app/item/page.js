import Item from '../pages/items';

export default function ItemPage() {
  return <Item />;
}
