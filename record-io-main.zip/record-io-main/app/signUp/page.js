import SignUp from '../pages/signUp';

export default function LoginPage() {
  return <SignUp />;
}
