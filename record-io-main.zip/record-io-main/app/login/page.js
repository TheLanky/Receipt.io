import Login from '../pages/login';

export default function LoginPage() {
  return <Login />;
}
