import Edit from '../pages/edit-item';

export default function EditPage() {
  return <Edit />;
}
