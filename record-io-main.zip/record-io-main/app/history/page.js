import History from '../pages/history';

export default function HistoryPage() {
  return <History />;
}
